﻿There are several prerequisites for using this template.

1. You must use Visual Studio 2010 Professional or above.
2. You must install the Windows Phone Developer Tools from http://developer.windowsphone.com/windows-phone-7/.
   Additional information including documentation, links to tools, samples, etc. can be found at
   http://developer.windowsphone.com/windows-phone-7/.
3. You must install Microsoft Silverlight 4 Tools for Visual Studio 2010 which 
   can be downloaded from http://www.microsoft.com/downloads/details.aspx?FamilyID=40EF0F31-CB95-426D-9CE0-00DCFABF3DF5&displaylang=en.

Visit http://blogs.msdn.com/b/dsyme/archive/2010/08/17/demos-for-tonight-s-quot-community-for-f-quot-online-live-meeting.aspx 
for more information.